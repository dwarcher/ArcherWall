#include "wallApp.h"

//--------------------------------------------------------------
void wallApp::setup(){
	testImg.loadImage("wall.jpg");
	testTexture.loadImage("testpattern.png");
	ofSetFullscreen(true);
	ofSetEscapeQuitsApp(true);

	for(int i=0; i<NUMSTRIPS; i++)
	{
		stripFBO[i].allocate(1024, 128, true);

		strips[i].setMode(OF_PRIMITIVE_TRIANGLE_STRIP);

		//mesh.addVertex(ofVec3f(leftPoint.x, leftPoint.y, leftPoint.z));
		//mesh.addVertex(ofVec3f(rightPoint.x, rightPoint.y, rightPoint.z));
	}

	cursorX = 0;
	cursorY = 0;


	currentStrip = 0;
	expectedDivisions = 5;

	myfont.loadFont("Prototype.ttf", 32);

	drawBack = true;
	ph = 0;
}

//--------------------------------------------------------------
void wallApp::update(){

}

//--------------------------------------------------------------
void wallApp::draw(){
	for(int i=0; i<NUMSTRIPS; i++)
	{
		stripFBO[i].begin();

		ofClear(0,0,0,0);
		ofSetColor(255, 0, 0, 255);
		ofRect((ph + (i * 128)) % 1024, 0, 256, 128);
		ph += 1;

		ph %= 1024;

		stripFBO[i].end();
	}

	ofClear(0,0,0,0);

	if(drawBack)
	{
		ofSetColor(255, 255, 255, 255);
		testImg.draw(ofGetWindowRect());

	}
	ofSetColor(255, 0, 0, 255);

	std::stringstream ss;
	ss << "Strip: " << currentStrip;

	myfont.drawString(ss.str().c_str(), 40, 40);

	for(int i=0; i<NUMSTRIPS; i++)
	{
		if(i == currentStrip)
		{
			ofSetColor(255, 128, 128, 255);
		} else {

			ofSetColor(255, 255, 255, 64);

		}
		stripFBO[i].bind();
		strips[i].draw();
		stripFBO[i].unbind();
	}

	ofSetColor(255, 255, 255, 255);

	ofLine(cursorX-10, cursorY, cursorX + 10, cursorY);
	ofLine(cursorX, cursorY-10, cursorX, cursorY+10);

	//testFBO.draw(50, 300);
}

void wallApp::saveAll()
{
	for(int i=0; i<NUMSTRIPS; i++)
	{
		stringstream ss;
		ss << "stream" << i << ".dat";
		strips[i].save(ss.str());
	}

}

void wallApp::loadAll()
{
	for(int i=0; i<NUMSTRIPS; i++)
	{
		stringstream ss;
		ss << "stream" << i << ".dat";
		strips[i].load(ss.str());
	}
}

//--------------------------------------------------------------
void wallApp::keyPressed(int key){
	switch(key)
	{
	case OF_KEY_UP:
		if(currentStrip)
			currentStrip--;
		break;
	case OF_KEY_DOWN:
		if(currentStrip < 9)
			currentStrip++;
		break;
	case OF_KEY_BACKSPACE:
	case OF_KEY_DEL:
		strips[currentStrip].removeVertex(strips[currentStrip].getNumVertices() - 1);
		strips[currentStrip].removeTexCoord(strips[currentStrip].getNumTexCoords() - 1);

		break;

	case 's':
		saveAll();
		break;
	case 'l':
		loadAll();
		break;
	case 'b':
		drawBack = !drawBack;
		break;
	}
}

//--------------------------------------------------------------
void wallApp::keyReleased(int key){

}

//--------------------------------------------------------------
void wallApp::mouseMoved(int x, int y ){
	cursorX = x;
	cursorY = y;
}

//--------------------------------------------------------------
void wallApp::mouseDragged(int x, int y, int button){
	cursorX = x;
	cursorY = y;
}

//--------------------------------------------------------------
void wallApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void wallApp::mouseReleased(int x, int y, int button){
	cursorX = x;
	cursorY = y;

	int div = strips[currentStrip].getNumVertices() / 2;
	float u = (float)div / (float)expectedDivisions;
	float v = 0.0;
	if(strips[currentStrip].getNumVertices() & 1)
		v = 1.0;

	strips[currentStrip].addVertex(ofVec3f(x, y, 0));
	strips[currentStrip].addTexCoord(ofVec2f(u * stripFBO[currentStrip].getWidth(), v * stripFBO[currentStrip].getHeight() ));
}

//--------------------------------------------------------------
void wallApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void wallApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void wallApp::dragEvent(ofDragInfo dragInfo){ 

}